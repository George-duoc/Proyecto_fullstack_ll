import './App.css'
import Autos from './pages/Autos.jsx'
import Login from './pages/Login.jsx'

function App() {
  const paginaLogin = window.location.pathname === '/login'

  return (
    paginaLogin ? <Login /> : <Autos />
  )
}

export default App
