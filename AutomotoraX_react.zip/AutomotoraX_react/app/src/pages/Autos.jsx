import { useEffect, useState } from 'react';

const stockVehiculos = [
	{
		id: 1,
		nombre: 'Nissan Skyline GT-R R34',
		descripcion: 'Lo mejor de la ingeniería JDM, disfrútalo solo en Automotora X.',
		precio: 10000000,
		imagen: 'https://preview.redd.it/nissan-skyline-gt-r-r34-one-of-the-most-iconic-japanese-v0-wdc7erjx1plf1.jpeg?width=1080&crop=smart&auto=webp&s=4526eac04a81103a98ab921dd571b940c41b4da8',
	},
	{
		id: 2,
		nombre: 'Ford Mustang GT',
		descripcion: 'Si entiendes lo que significa motor Coyote V8 de 4.ª generación, esta es tu opción.',
		precio: 10000000,
		imagen: 'https://hips.hearstapps.com/hmg-prod/images/img-2033-jpg-64bec5598090f.jpg?crop=0.872xw:0.655xh;0.0833xw,0.186xh&resize=1400:*',
	},
	{
		id: 3,
		nombre: 'Lamborghini Huracán',
		descripcion: 'El superdeportivo definitivo: furia pura de un V10 atmosférico de 640 caballos de fuerza.',
		precio: 10000000,
		imagen: 'https://www.lamborghinilongisland.com/imagetag/2343/9/l/New-2019-Lamborghini-Huracan-RWD-Coupe-1553631677.jpg',
	},
	{
		id: 4,
		nombre: 'Porsche 911 Carrera 2025',
		descripcion: 'Deportivo de lujo con motor trasero bóxer, diseño 2+2 plazas y una combinación única de deportividad y uso diario.',
		precio: 13999990,
		imagen: 'https://www.motortrend.com/files/668d77e37dd43700087fa89b/006-2025-porsche-911-carrera.jpg',
	},
	{
		id: 5,
		nombre: 'Bugatti Chiron 2023',
		descripcion: 'Hiperdeportivo de lujo con motor W16 de 8 litros y 1.500 CV, capaz de alcanzar hasta 420 km/h.',
		precio: 20000000,
		imagen: 'https://cdn.motor1.com/images/mgl/VzMq0z/s1/bugatti-chiron-1500.jpg',
	},
	{
		id: 6,
		nombre: 'Honda Civic Type R 2021',
		descripcion: 'Motor 2.0 turbo que supera los 300 hp, con una entrega de potencia lineal y rápida.',
		precio: 9999990,
		imagen: 'https://tse1.mm.bing.net/th/id/OIP.gIa0FAn8o0JhYYXHqi9vQQHaE8?r=0&rs=1&pid=ImgDetMain&o=7&rm=3',
	},
];

function cargarCarrito() {
	try {
		const carritoGuardado = JSON.parse(localStorage.getItem('miCarrito') ?? '[]');
		return Array.isArray(carritoGuardado) ? carritoGuardado : [];
	} catch {
		return [];
	}
}

export default function Autos() {
	const [carrito, setCarrito] = useState(cargarCarrito);

	useEffect(() => {
		localStorage.setItem('miCarrito', JSON.stringify(carrito));
	}, [carrito]);

	function agregarAlCarrito(auto) {
		setCarrito((carritoActual) => [
			...carritoActual,
			{ id: auto.id, nombre: auto.nombre, precio: auto.precio },
		]);
	}

	return (
		<>
			<header className="bg-dark text-white">
				<nav className="container navbar navbar-dark py-3" aria-label="Navegación principal">
					<a className="navbar-brand fw-semibold" href="/">AutomotoraX</a>
					<div className="d-flex align-items-center gap-3">
						<span className="text-white" aria-live="polite">
							Carrito <span className="badge text-bg-light text-dark">{carrito.length}</span>
						</span>
						<a className="btn btn-outline-light btn-sm" href="/login">Iniciar sesión</a>
					</div>
				</nav>
			</header>

			<main className="container py-5">
				<h1 className="text-center mb-4 border-bottom border-secondary pb-2">Autos disponibles</h1>

				<div className="row g-4" aria-label="Catálogo de autos">
					{stockVehiculos.map((auto) => (
						<div className="col-sm-6 col-lg-4" key={auto.id}>
							<article className="card h-100 shadow-sm">
								<img
									src={auto.imagen}
									className="card-img-top imagen-catalogo"
									alt={auto.nombre}
									loading="lazy"
								/>
								<div className="card-body">
									<h2 className="card-title h5">{auto.nombre}</h2>
									<p className="card-text">{auto.descripcion}</p>
								</div>
								<div className="card-footer bg-white d-flex justify-content-between align-items-center gap-2">
									<span className="fw-bold">
										${auto.precio.toLocaleString('es-CL')}
									</span>
									<button
										className="btn btn-dark btn-sm"
										type="button"
										onClick={() => agregarAlCarrito(auto)}
									>
										Agregar al carrito
									</button>
								</div>
							</article>
						</div>
					))}
				</div>
			</main>
		</>
	);
}
