import { useEffect, useState } from 'react';

export default function Login() {
	const [usuario, setUsuario] = useState('');
	const [contrasena, setContrasena] = useState('');
	const [mostrarContrasena, setMostrarContrasena] = useState(false);
	const [mensaje, setMensaje] = useState(null);

	useEffect(() => {
		document.title = 'AutomotoraX | Iniciar sesión';
	}, []);

	function iniciarSesion(evento) {
		evento.preventDefault();

		if (usuario === 'admin' && contrasena === '1234') {
			setMensaje({ tipo: 'success', texto: 'Inicio de sesión correcto.' });
			return;
		}

		setMensaje({ tipo: 'danger', texto: 'Usuario o contraseña incorrectos.' });
	}

	return (
		<div className="d-flex min-vh-100 flex-column">
			<header className="bg-dark text-white">
				<nav className="container navbar navbar-dark py-3" aria-label="Navegación principal">
					<a className="navbar-brand fw-semibold" href="/">AutomotoraX</a>
					<a className="btn btn-outline-light btn-sm" href="/">Volver al catálogo</a>
				</nav>
			</header>

			<main className="container flex-grow-1 d-flex align-items-center justify-content-center py-5">
				<div className="row justify-content-center w-100">
					<div className="col-md-8 col-lg-6">
						<section className="card shadow border-0 rounded-4">
							<div className="card-body p-4 p-md-5">
								<h1 className="h2 text-center mb-2">Iniciar sesión</h1>
								<p className="alert alert-info text-center mb-4" role="status">
									Demo: usuario <strong>admin</strong>, contraseña <strong>1234</strong>.
								</p>

								<form onSubmit={iniciarSesion}>
									<div className="mb-3">
										<label htmlFor="username" className="form-label fw-semibold">Usuario</label>
										<input
											id="username"
											className="form-control form-control-lg"
											type="text"
											placeholder="admin"
											autoComplete="username"
											value={usuario}
											onChange={(evento) => setUsuario(evento.target.value)}
											required
										/>
									</div>

									<div className="mb-3">
										<label htmlFor="password" className="form-label fw-semibold">Contraseña</label>
										<div className="input-group">
											<input
												id="password"
												className="form-control form-control-lg"
												type={mostrarContrasena ? 'text' : 'password'}
												placeholder="Ingresa tu contraseña"
												autoComplete="current-password"
												value={contrasena}
												onChange={(evento) => setContrasena(evento.target.value)}
												required
											/>
											<button
												className="btn btn-outline-secondary"
												type="button"
												aria-label={mostrarContrasena ? 'Ocultar contraseña' : 'Mostrar contraseña'}
												aria-pressed={mostrarContrasena}
												onClick={() => setMostrarContrasena((visible) => !visible)}
											>
												{mostrarContrasena ? 'Ocultar' : 'Mostrar'}
											</button>
										</div>
									</div>

									<div className="d-grid">
										<button type="submit" className="btn btn-primary btn-lg rounded-3">
											Ingresar a mi cuenta
										</button>
									</div>
									{mensaje && (
										<div className={`alert alert-${mensaje.tipo} mt-3 mb-0`} role="alert">
											{mensaje.texto}
										</div>
									)}
								</form>
							</div>
						</section>
					</div>
				</div>
			</main>
		</div>
	);
}