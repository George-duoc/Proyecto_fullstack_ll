const vehiculos = [
    {
        nombre: 'Nissan Skyline GT-R R34',
        imagen: 'https://preview.redd.it/nissan-skyline-gt-r-r34-one-of-the-most-iconic-japanese-v0-wdc7erjx1plf1.jpeg?width=1080&crop=smart&auto=webp&s=4526eac04a81103a98ab921dd571b940c41b4da8',
        descripcion: 'Lo mejor de la ingeniería JDM, disfrútalo solo en Automotora X.',
    },
    {
        nombre: 'Ford Mustang GT',
        imagen: 'https://hips.hearstapps.com/hmg-prod/images/img-2033-jpg-64bec5598090f.jpg?crop=0.872xw:0.655xh;0.0833xw,0.186xh&resize=1400:*',
        descripcion: 'Si entiendes lo que significa motor Coyote V8 de 4.ª generación, esta es tu opción.',
    },
    {
        nombre: 'Lamborghini Huracán',
        imagen: 'https://www.lamborghinilongisland.com/imagetag/2343/9/l/New-2019-Lamborghini-Huracan-RWD-Coupe-1553631677.jpg',
        descripcion: 'El superdeportivo definitivo: furia pura de un V10 atmosférico de 640 caballos de fuerza.',
    },
];

export default function Inicio() {
    return (
        <>
            <header className="bg-dark text-white">
                <nav className="container navbar navbar-dark py-3" aria-label="Navegación principal">
                    <a className="navbar-brand fw-semibold" href="#inicio">AutomotoraX</a>
                    <a className="btn btn-outline-light btn-sm" href="#reliquias">Iniciar sesión</a>
                </nav>
            </header>

            <main id="inicio" className="container py-4">
                <section className="text-center mt-2 mb-4">
                    <h1 className="display-5 fw-bold text-uppercase">Nuestras reliquias, ¡adelante!</h1>
                </section>

                <section id="reliquias" aria-label="Vehículos destacados">
                    <div id="carouselVehiculos" className="carousel slide" data-bs-ride="carousel">
                        <div className="carousel-indicators">
                            {vehiculos.map((vehiculo, index) => (
                                <button
                                    key={vehiculo.nombre}
                                    type="button"
                                    data-bs-target="#carouselVehiculos"
                                    data-bs-slide-to={index}
                                    className={index === 0 ? 'active' : ''}
                                    aria-current={index === 0 ? 'true' : undefined}
                                    aria-label={`Ir al vehículo ${index + 1}: ${vehiculo.nombre}`}
                                />
                            ))}
                        </div>

                        <div className="carousel-inner">
                            {vehiculos.map((vehiculo, index) => (
                                <div key={vehiculo.nombre} className={`carousel-item${index === 0 ? ' active' : ''}`}>
                                    <img
                                        src={vehiculo.imagen}
                                        className="d-block w-100 imagen-uniforme"
                                        alt={vehiculo.nombre}
                                    />
                                    <div className="carousel-caption d-block">
                                        <h2 className="h5 text-white fw-bold text-uppercase bg-dark bg-opacity-75 d-inline-block px-3 py-2 rounded">
                                            {vehiculo.nombre}
                                        </h2>
                                        <p className="text-white fw-semibold bg-dark bg-opacity-75 d-inline-block px-3 py-1 rounded">
                                            {vehiculo.descripcion}
                                        </p>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <button className="carousel-control-prev" type="button" data-bs-target="#carouselVehiculos" data-bs-slide="prev">
                            <span className="carousel-control-prev-icon" aria-hidden="true" />
                            <span className="visually-hidden">Anterior</span>
                        </button>
                        <button className="carousel-control-next" type="button" data-bs-target="#carouselVehiculos" data-bs-slide="next">
                            <span className="carousel-control-next-icon" aria-hidden="true" />
                            <span className="visually-hidden">Siguiente</span>
                        </button>
                    </div>
                </section>
            </main>
        </>
    );
}